﻿using System;
using System.Collections.Generic;
using System.Text;

namespace MusicHub.Data.Models.Enums
{
    public enum Genre
    {
        Blues = 0,
        Rap = 1,
        PopMusic = 2,
        Rock = 3,
        Jazz = 4,
    }
}
