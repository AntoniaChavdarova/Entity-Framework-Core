﻿using System;
using System.Collections.Generic;
using System.Text;

namespace P01_HospitalDatabase.Data
{
    internal class Configuration
    {
        internal static string ConnectionString = @"Server=.;Database=HospitalDatabase;Integrated Security=true;";
    }
}
