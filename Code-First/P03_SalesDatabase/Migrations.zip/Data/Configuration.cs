﻿using System;
using System.Collections.Generic;
using System.Text;

namespace P03_SalesDatabase.Data
{
    internal class Configuration
    {
        internal static string ConnectionString = @"Server=.;Database=SalesDatabase;Integrated Security=true;";
    }
}
