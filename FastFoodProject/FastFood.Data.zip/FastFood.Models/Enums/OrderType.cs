namespace FastFood.Models.Enums
{
	public enum OrderType
	{
		ForHere = 0,
		ToGo = 1
	}
}