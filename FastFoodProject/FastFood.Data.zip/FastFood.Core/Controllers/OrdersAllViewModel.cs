﻿namespace FastFood.Core.Controllers
{
    internal class OrdersAllViewModel
    {
    }
}