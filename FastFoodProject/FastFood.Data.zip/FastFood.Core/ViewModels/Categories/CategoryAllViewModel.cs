﻿namespace FastFood.Core.ViewModels.Categories
{
    public class CategoryAllViewModel
    {
        public string Name { get; set; }
    }
}
